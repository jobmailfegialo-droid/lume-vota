# Guida Italia

Dati © OpenStreetMap contributors, distribuiti secondo Open Database License 1.0 (ODbL). L’estratto di partenza è pubblicato da Geofabrik. La data dei dati è in metadata.json. I file cells.json e settlements.json costituiscono la banca dati derivata e sono redistribuibili sotto la stessa licenza.

- [OpenStreetMap e attribuzione](https://www.openstreetmap.org/copyright)
- [Open Database License 1.0](https://opendatacommons.org/licenses/odbl/1-0/)
- [Estratto nazionale completo](https://download.geofabrik.de/europe/italy/)

Per rigenerare la guida, estrarre i nodi e le aree nominate con scripts/extract_italy.py, quindi eseguire scripts/build_italy_index.py fornendo il timestamp di replica dell’estratto. L’indice contiene punti e vie mappati, con una posizione rappresentativa calcolata per le vie. La categoria, la cucina, l’indirizzo e i servizi provengono dai tag OSM. Un dato assente resta sconosciuto. L’elenco include le attività censite al momento dell’estrazione.
